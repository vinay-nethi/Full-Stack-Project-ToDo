import React, { useEffect, useState } from 'react'
import { addTodoApi, editTodoApi } from './APIs/customerApi'
import { useLocation, useNavigate } from 'react-router-dom'

const CreateTodo = () => {
    const [formInfo, setFormInfo] = useState({
        title:"",
        description:"",
        date:"",
        time:""
    })
    const location=useLocation()
    const [token,setToken]=useState(location?.state[2])
    // console.log("location data",location.state)
    const activityCheck=location?.state[1]==="edit" ? "Update Blog" : "Add Blog";
    const navigate = useNavigate()
    const onChangeTodo = (e) => {
        try {
            let name = e.target.name
            let value = e.target.value
            setFormInfo((pv) => ({ ...pv, [name]: value }))

        } catch (e) {
            console.log(e)
        }
    }
    const onSubmitFormData=(e)=>{
        e.preventDefault()

    }
    const onPostTodo=async()=>{
        try{
            if(activityCheck==="Add Blog"){
                await addTodoApi(formInfo)
            // console.log("token",token)
            navigate("/todo",{state:token})

            }else{
                let reqId=location.state[0]._id
                const res=await editTodoApi(reqId,formInfo)
                if(res.data.message==="todo updated"){
                    navigate("/todo",{state:location.state[2]})
                }
            }

            
            // console.log("location info",location.state)
         
        }catch(e){
            console.log(e)
        }
    }
    // const createTodoDemo=async()=>{
    //     await axios.post("http://localhost:8080/addtodo",)

    // }
    const editTodoValues=()=>{
        document.getElementById("title").value=location.state[0].title
        document.getElementById("description").value=location.state[0].description
        document.getElementById("date").value=location.state[0].date
        document.getElementById("time").value=location.state[0].time


        setFormInfo(location.state[0])


    }
    useEffect(()=>{
        editTodoValues()
    },[])
    return (
        <form onSubmit={onSubmitFormData}>
            <label>Enter Title:</label>
            <br />
            <input type="text" className="createTodoinput" name="title" id="title" onChange={onChangeTodo} />
            <br />

            <label>Enter Description:</label>
            <br />
            <input type="text" className="createTodoinput" name="description" id="description" onChange={onChangeTodo} />
            <br />

            <label>Enter Date:</label>
            <br />
            <input type="date" className="createTodoinput" name="date" id="date" onChange={onChangeTodo} />
            <br />

            <label>Enter Time:</label>
            <br />
            <input type="time" className="createTodoinput" name="time" id="time" onChange={onChangeTodo} />
            <br />

            <button onClick={onPostTodo}>{activityCheck}</button>
        </form>
    )
}

export default CreateTodo
